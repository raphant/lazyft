"""
20200723-20200901 00:00:00 (40 days)

    374 trades.
    283/88/3 Wins/Draws/Losses.
    Avg profit   1.03%.
    Median profit   1.25%.
    Total profit  0.03543881 BTC ( 385.03Σ%).
    Avg duration 321.1 min.
    Objective: -587.81106
=============== SUMMARY METRICS ===============
| Metric                | Value               |
|-----------------------+---------------------|
| Backtesting from      | 2020-09-13 00:00:00 |
| Backtesting to        | 2020-09-21 12:12:00 |
| Total trades          | 93                  |
| First trade           | 2020-09-13 05:56:00 |
| First trade Pair      | IOST/BTC            |
| Total Profit %        | 76.7%               |
| Trades per day        | 11.62               |
| Best day              | 21.53%              |
| Worst day             | -11.72%             |
| Days win/draw/lose    | 8 / 0 / 1           |
| Avg. Duration Winners | 0:17:00             |
| Avg. Duration Loser   | 20:49:00            |
|                       |                     |
| Max Drawdown          | 32.42%              |
| Drawdown Start        | 2020-09-21 10:20:00 |
| Drawdown End          | 2020-09-21 12:12:00 |
| Market change         | -17.61%             |
===============================================

============================================================= STRATEGY SUMMARY =============================================================
|   Strategy |   Buys |   Avg Profit % |   Cum Profit % |   Tot Profit BTC |   Tot Profit % |   Avg Duration |   Wins |   Draws |   Losses |
|------------+--------+----------------+----------------+------------------+----------------+----------------+--------+---------+----------|
|      BinH4 |    111 |           0.42 |          46.77 |       0.00430501 |           0.00 |        0:27:00 |     64 |      26 |       21 |
|      BinH3 |     89 |           0.53 |          47.17 |       0.00434157 |           0.00 |        1:34:00 |     50 |      33 |        6 |
|      BinH6 |     93 |           0.82 |          76.70 |       0.00705933 |           0.00 |        1:54:00 |     65 |      24 |        4 |
============================================================================================================================================
    [
      "LINK/BTC",
      "XTZ/BTC",
      "FTM/BTC",
      "ALGO/BTC",
      "XEM/BTC",
      "SNM/BTC",
      "LEND/BTC",
      "ONT/BTC",
      "XMR/BTC",
      "LTC/BTC",
      "THETA/BTC",
      "NEO/BTC",
      "XRP/BTC",
      "MATIC/BTC",
      "AST/BTC",
      "ETH/BTC",
      "ATOM/BTC",
      "BAND/BTC",
      "OMG/BTC",
      "NKN/BTC",
      "LRC/BTC",
      "COTI/BTC",
      "BCH/BTC",
      "TRX/BTC",
      "ADA/BTC",
      "ADX/BTC",
      "IOST/BTC",
      "VET/BTC",
      "REN/BTC",
      "QTUM/BTC",
      "EOS/BTC",
      "VITE/BTC"
    ],
"""
# --- Do not remove these libs ---
from freqtrade.strategy.interface import IStrategy
from typing import Dict, List
from functools import reduce
from pandas import DataFrame
import numpy as np
# --------------------------------

import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

# ROI table:
minimal_roi = {
    "0":  0.05738,
    "5":  0.01442,
    "16": 0.0092,
    "40": 0
}

# Stoploss:
stoploss = -0.30169

# Trailing stop:
trailing_params = {
    'trailing_only_offset_is_reached': True,
    'trailing_stop':                   True,
    'trailing_stop_positive':          0.13097,
    'trailing_stop_positive_offset':   0.19963
}


def bollinger_bands(stock_price, window_size, num_of_std):
    rolling_mean = stock_price.rolling(window=window_size).mean()
    rolling_std = stock_price.rolling(window=window_size).std()
    lower_band = rolling_mean - (rolling_std * num_of_std)

    return rolling_mean, lower_band


class BinH6(IStrategy):
    minimal_roi = minimal_roi

    # Optimal stoploss designed for the strategy
    # This attribute will be overridden if the config file contains "stoploss"
    stoploss = stoploss

    locals().update(trailing_params)

    timeframe = '1m'

    def populate_indicators(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        mid, lower = bollinger_bands(dataframe['close'], window_size=40,
                                     num_of_std=2)
        dataframe['mid'] = np.nan_to_num(mid)
        dataframe['lower'] = np.nan_to_num(lower)
        dataframe['bbdelta'] = (dataframe['mid'] - dataframe['lower']).abs()
        dataframe['pricedelta'] = (
            dataframe['open'] - dataframe['close']).abs()
        dataframe['closedelta'] = (
            dataframe['close'] - dataframe['close'].shift()).abs()
        dataframe['tail'] = (dataframe['close'] - dataframe['low']).abs()
        return dataframe

    def populate_buy_trend(self, dataframe: DataFrame,
                           metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                dataframe['lower'].shift().gt(0) &
                dataframe['bbdelta'].gt(dataframe['close'] * 0.008) &
                dataframe['closedelta'].gt(dataframe['close'] * 0.0175) &
                dataframe['tail'].lt(dataframe['bbdelta'] * 0.25) &
                dataframe['close'].lt(dataframe['lower'].shift()) &
                dataframe['close'].le(dataframe['close'].shift()) &
                dataframe['volume'] > 0
            ),
            'buy'] = 1
        return dataframe

    def populate_sell_trend(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        """
        no sell signal
        """
        dataframe['sell'] = 0
        return dataframe
