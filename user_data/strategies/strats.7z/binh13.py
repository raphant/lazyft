"""
20200729-20200907 (40 days)..

    74/74:
    493 trades. 341/144/8 Wins/Draws/Losses.
    Avg profit   0.91%.
    Median profit   1.24%.
    Total profit  0.04183579 BTC ( 448.64Σ%).
    Avg duration 170.6 min.
    Objective: -11122.71746


[
   "LINK/BTC",
      "XTZ/BTC",
      "FTM/BTC",
      "ALGO/BTC",
      "XEM/BTC",
      "SNM/BTC",
      "LEND/BTC",
      "ONT/BTC",
      "XMR/BTC",
      "LTC/BTC",
      "THETA/BTC",
      "NEO/BTC",
      "XRP/BTC",
      "MATIC/BTC",
      "AST/BTC",
      "ETH/BTC",
      "ATOM/BTC",
      "BAND/BTC",
      "OMG/BTC",
      "NKN/BTC",
      "LRC/BTC",
      "COTI/BTC",
      "BCH/BTC",
      "TRX/BTC",
      "ADA/BTC",
      "ADX/BTC",
      "IOST/BTC",
      "VET/BTC",
      "REN/BTC",
      "QTUM/BTC",
      "EOS/BTC",
      "VITE/BTC"
    ],
"""
# --- Do not remove these libs ---
from freqtrade.strategy.interface import IStrategy
from typing import Dict, List
from functools import reduce
from pandas import DataFrame
import numpy as np
# --------------------------------

import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

# Buy hyperspace params:
buy_params = {
    'bb':                     '401',
    'bbdelta-close-value':    0.00661,
    'closedelta-close-value': 0.01309,
    'lower-value':            -0.89696,
    'tail-bbdelta-value':     0.26418
}

# ROI table:
minimal_roi = {
    "0": 0.0125
}
# Stoploss:
stoploss = -0.05

# Trailing stop:
trailing_params = {
    'trailing_only_offset_is_reached': True,
    'trailing_stop':                   True,
    'trailing_stop_positive':          0.17356,
    'trailing_stop_positive_offset':   0.24957
}


def bollinger_bands(stock_price, window_size, num_of_std):
    rolling_mean = stock_price.rolling(window=window_size).mean()
    rolling_std = stock_price.rolling(window=window_size).std()
    lower_band = rolling_mean - (rolling_std * num_of_std)

    return rolling_mean, lower_band


class BinH13(IStrategy):
    minimal_roi = minimal_roi

    # Optimal stoploss designed for the strategy
    # This attribute will be overridden if the config file contains "stoploss"
    stoploss = stoploss

    locals().update(trailing_params)

    timeframe = '1m'

    def populate_indicators(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        for opt in ['201', '202', '401', '402']:
            mid, lower = bollinger_bands(dataframe['close'],
                                         window_size=int(opt[:2]),
                                         num_of_std=int(opt[2]))
            dataframe['mid_' + opt] = np.nan_to_num(mid)
            dataframe['lower_' + opt] = np.nan_to_num(lower)
            dataframe['bbdelta_' + opt] = (
                dataframe['mid_' + opt] - dataframe['lower_' + opt]).abs()

        dataframe['pricedelta'] = (
            dataframe['open'] - dataframe['close']).abs()
        dataframe['closedelta'] = (
            dataframe['close'] - dataframe['close'].shift()).abs()
        dataframe['tail'] = (dataframe['close'] - dataframe['low']).abs()
        return dataframe

    def populate_buy_trend(self, dataframe: DataFrame,
                           metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                dataframe['lower_' + buy_params['bb']].shift().gt(
                    buy_params['lower-value']) &

                dataframe['bbdelta_' + buy_params['bb']].gt(
                    dataframe['close'] * buy_params['bbdelta-close-value']) &

                dataframe['closedelta'].gt(dataframe['close'] * buy_params[
                    'closedelta-close-value']) &

                dataframe['tail'].lt(
                    dataframe['bbdelta_' + buy_params['bb']] * buy_params[
                        'tail-bbdelta-value']) &

                dataframe['close'].lt(
                    dataframe['lower_' + buy_params['bb']].shift()) &

                dataframe['close'].le(dataframe['close'].shift()) &

                dataframe['volume'] > 0
            ),
            'buy'] = 1
        return dataframe

    def populate_sell_trend(self, dataframe: DataFrame,
                            metadata: dict) -> DataFrame:
        """
        no sell signal
        """
        dataframe['sell'] = 0
        return dataframe
