# BB RSI CMF FAST CCI
Stake Currency: USDT
Max Open Trades: 3
Wallet: 1000
