# BB RSI CMF FAST CCI
Stake Currency: BTC
Max Open Trades: 12
Wallet: 1000
